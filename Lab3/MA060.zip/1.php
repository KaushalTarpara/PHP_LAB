<?php
$a = array(
    "name" => "jaivin domadiya",
    "age" => 21,
    "city" => "Junagadh",
    "email" => "jaivin@gmail.com",
    "state" => "Gujatat"
);

foreach ($a as $key => $value) {
    echo " $key :  $value <br>";
}
?>
