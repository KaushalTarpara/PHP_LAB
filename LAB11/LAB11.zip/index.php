<?php

namespace LAB11;

require_once './Controller/EmployeeController.php';

use LAB11\Controller\EmployeeController;

EmployeeController::All();
