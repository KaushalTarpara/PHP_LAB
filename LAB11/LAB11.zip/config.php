<?php

namespace LAB11;

class Config
{
    protected const HOST = "localhost";
    protected const DATABASE = "emp";
    protected const USERNAME = "root";
    protected const PASSWORD = "";
  //  protected const PORT = 3307;
}
