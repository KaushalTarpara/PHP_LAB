<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "person";
?>

