<?php
$var1 = 10;
$var2 = 5;

$add = $var1 + $var2;
$sub = $var1 - $var2;
$multi = $var1 * $var2;
$divi = $var1 / $var2;
$mod = $var1 % $var2;

echo "Variable 1: " . $var1 . "<br>";
echo "Variable 2: " . $var2 . "<br><br>";

echo "Addition: " . $add . "<br>";
echo "Subtraction: " . $sub . "<br>";
echo "Multiplication: " . $multi . "<br>";
echo "Division: " . $divi . "<br>";
echo "Modulus: " . $mod . "<br>";
?>