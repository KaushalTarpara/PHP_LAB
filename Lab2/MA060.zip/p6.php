<?php
    $str1 = "Marvel movie is best:";
    $str2 = "Action and VFX All time:";

    $con = $str1.$str2;

    $str1 .= $str2;

    echo "<b>Concatenation::$con<b>";
    echo "<br>";
    echo "<b>Concatenation & Assighment::$str1<b>";

    

?>