<?php
$backgroundColor = "yellow";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dynamic Background Color</title>
</head>
<body>
    <div style="background-color: <?php echo $backgroundColor; ?>;">
        <h1>Lucifer moringstar is a Devil</h1>
        <p>This is an example of changing the background color using PHP.</p>
    </div>
</body>
</html>
