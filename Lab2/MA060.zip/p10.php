<?php
for ($i = 1; $i <= 19; $i += 2) {
    echo $i . " ";
}
?>
