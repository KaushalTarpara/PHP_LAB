<?php

$var1 = 10;
$var2 = 5;

$equal = $var1 == $var2;
$notEqual = $var1 != $var2;
$greaterThan = $var1 > $var2;
$lessThan = $var1 < $var2;
$greaterThanOrEqual = $var1 >= $var2;
$lessThanOrEqual = $var1 <= $var2;

echo "Variable 1:$var1 ";
echo "<br>";
echo "Variable 2:$var2";
echo "<br>";
echo "Equal (==):$equal" ;
echo "<br>";
echo "Not Equal (!=):$notEqual";
echo "<br>";
echo "Greater Than (>):$greaterThan";
echo "<br>";
echo "Less Than (<):$lessThan";
echo "<br>";
echo "Greater Than or Equal (>=):$greaterThanOrEqual";
echo "<br>";
echo "Less Than or Equal (<=):$lessThanOrEqual";
echo "<br>";
?>
