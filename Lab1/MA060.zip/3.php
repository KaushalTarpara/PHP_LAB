<?php
    echo "<h1>";
    echo "Name : Kaushal Tarpara <br>";
    echo "RollNo : MA060 <br>";
    echo "Sem 2 SPI : 8.44 <br>";
    echo "</h1>";
?>