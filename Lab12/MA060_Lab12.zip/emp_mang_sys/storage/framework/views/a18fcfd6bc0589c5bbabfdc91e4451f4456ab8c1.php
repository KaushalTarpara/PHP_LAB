<!DOCTYPE html>
<html>
<head>
    <title>Create Employee</title>
</head>
<body>
    <h1>Create Employee</h1>
    <form action="<?php echo e(route('employees.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="name">Name:</label>
        <input type="text" name="name" required><br>
        <label for="department">Department:</label>
        <input type="text" name="department" required><br>
        <button type="submit">Add Employee</button>
    </form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PHPLabs\Lab12\emp_mang_sys\resources\views/employees/create.blade.php ENDPATH**/ ?>