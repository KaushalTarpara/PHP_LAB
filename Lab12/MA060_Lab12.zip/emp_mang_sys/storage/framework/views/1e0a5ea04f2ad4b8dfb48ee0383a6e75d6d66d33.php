<!DOCTYPE html>
<html>
<head>
    <title>Employee List</title>
</head>
<body>
    <h1>Employee List</h1>
    <ul>
        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($employee->name); ?> - <?php echo e($employee->department); ?>

                <a href="<?php echo e(route('employees.edit', $employee->employee_id)); ?>">Edit</a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <a href="<?php echo e(route('employees.create')); ?>">Add Employee</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\PHPLabs\Lab12\emp_mang_sys\resources\views/employees/index.blade.php ENDPATH**/ ?>